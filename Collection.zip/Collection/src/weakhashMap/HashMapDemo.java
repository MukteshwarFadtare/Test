package weakhashMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


public class HashMapDemo {
	public static void main(String[] args) throws InterruptedException {

		HashMap m =new HashMap();
		
		Temp t = new Temp();
		
		m.put(t," java");
		
		System.out.println(m);
		
		t= null;
		
		System.gc(); //here HashMap dominates gc therefore gc cant collect this particular object
		
		Thread.sleep(2000);
		
		System.out.println(m); // we get our object here safely
		
		
	}

}
