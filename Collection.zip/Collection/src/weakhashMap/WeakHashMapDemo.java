package weakhashMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;

public class WeakHashMapDemo {
	public static void main(String[] args) throws InterruptedException {

		WeakHashMap m = new WeakHashMap();

		Temp t = new Temp();

		m.put(t, " java");

		System.out.println(m);

		t = null;

		System.gc(); //here gc dominates weakhashmap therefore gc collect this particular object

		Thread.sleep(2000);

		System.out.println(m);
	}

}
