package Colloction_Utility;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArraysAsList {
	
	public static void main(String[] args) {
		
		String[] s= {"SHAN","MRF","DK"};
		
		for(String s1 : s)
		{
			System.out.print(" "+s1);
		}
		
		//convert array into list
		List l1 = Arrays.asList(s);
		
		System.out.println(l1);
		
		
		//for Integer
		
		int[] n={10,8,74,02};
		
		for(int n1 : n)
		{
			System.out.print(" "+n1);
		}
		
		//convert array into list
		System.out.println("=================================");
		List l = Arrays.asList(n);
		
		System.out.println("Integer array as a List :- "+l);
		
		Iterator itr = l.iterator();
		if(itr.hasNext())
		{
			int[] n2 = (int[]) itr.next();
			
			for(int n3 : n2)
			{
				System.out.print(" "+n3);
			}
		}
		
		
		
	}

}
