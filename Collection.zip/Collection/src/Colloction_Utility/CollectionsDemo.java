package Colloction_Utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {
		
		List l = new ArrayList();
		
		l.add(10);
		l.add(15);
		l.add(12);
		l.add(14);
		l.add(13);
		l.add(19);
		l.add(21);
		
		System.out.println(l);
		//Collections.reverse(l);//use to reverse the list
		//Collections.sort(l);
		Collections.sort(l, new MyComparator());
		System.out.println(l);
		
		
		/*Collections.sort(l,new MyComparator());
		
		
		System.out.println(Collections.binarySearch(l, 16,new MyComparator()));
		
		System.out.println(l);
		*/
		
	}
	
}
