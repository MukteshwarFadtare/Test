package Colloction_Utility;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArraysDmo {
	
	public static void main(String[] args) {
		
	int a[] ={1,2,7,8,5,10,48,3};
	
	//System.out.println(a);
	
	Arrays.sort(a);//by using this we get default natural sorting order(DNSO)
	
	
	//iterate array or print array
	
	for(int i : a)
	{
		System.out.print("  "+i);
	}
	System.out.println();
	//binary serach method
		
	//DSNO :-   1  2  3  5  7  8  10  48
	
	System.out.println(Arrays.binarySearch(a, 16));//if u pass 10 it will return 6 index according to DNSO and if we pass 16 ==> return -8
	
	
	
	}
}
