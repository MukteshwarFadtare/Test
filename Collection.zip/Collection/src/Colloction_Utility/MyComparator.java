package Colloction_Utility;

import java.util.Comparator;

public class MyComparator implements Comparator {

	@Override
	public int compare(Object arg0, Object arg1) {
		
		Integer a = (Integer)arg0;
		Integer b = (Integer)arg1;
		//return b.compareTo(a);
		if(a > b)
		{
			return -1;
		}
		else if(a == b)
		{
			return 0;
					}
		else
		{
			return 1;
		}
	}
	
	
}
