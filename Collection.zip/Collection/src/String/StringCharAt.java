package String;

public class StringCharAt {

	public static void main(String[] args) {
		System.out.println("main started...");
		String s = "Java Concept Of The Day";

		System.out.println(s.charAt(5)); // Output : C

		System.out.println(s.charAt(10)); // Output : p

		//System.out.println(s.charAt(25)); // This statement will throw
											// StringIndexOutOfBoundsException
	}
}
