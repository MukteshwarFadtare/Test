package String;

public class StringSubString {

	
	public static void main(String[] args) {
		
		String s = "gaurav abale";
		String k="";
		String[] s1 = s.split(" ");
		
		for(String s3 : s1)
		{
		 k+= " "+ s3.substring(0, 1).toUpperCase()+s3.substring(1);
		}
		
	System.out.println(k);
	
	
	
	
String name ="mukteshwar";

//String myName = name.substring(0, 1).toUpperCase()+name.substring(1);
System.out.println(name.substring(0, 1).toUpperCase()+name.substring(1));

	
	
	}
}
