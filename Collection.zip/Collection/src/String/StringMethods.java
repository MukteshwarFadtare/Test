package String;

public class StringMethods {

	public static void main(String[] args) {
		
		String s = "Mukteshwar";
		
		//char charAt(2) --> return that character which located at 2nd index
		System.out.println("charAt method  result :- " +s.charAt(2)); // k
		
		//int codePointAt(int index) it will return Ascii value of that particular character
		System.out.println("codePointAt method  result :- " +s.codePointAt(8)); //  here 'a' char is located at 8th index so it will return 97
		
		//int codePointBefore(int index) it will return Ascii value of that particular character which is located at index - 1
		System.out.println("codePointBefore method  result :- " +s.codePointBefore(8)); // it will return the ascii value of index - 1 means value of w --> 119
		
		//int codePointCount(int biginIndex , int endIndex) --> it will return the number of character available between start index and end Index
		System.out.println("codePointCount method  result :- " +s.codePointCount(2, 8)); // return 8
		
		//int compareTo(String anotherString) //return pos+,zero,neg- when other string greter than,equal,less than
		System.out.println("compareTo method  result :- " +s.compareTo("MuktesH"));
		
		//int compareToIgnoreCase(String anotherString) //return pos+,zero,neg- when other string greter than,equal,less than // here just Igore case
		System.out.println("compareToIgnoreCase method  result :- " +s.compareToIgnoreCase("MuktesH"));
		
		//String concat(String str); // return new String with modfication
		System.out.println("concat method  result :- " +s.concat(" Fadtare")); // return Mukteshwar Fadtare
		System.out.println(s); //but original string can't modified here o/p remain --> Mukteshwar
		
		//boolean contains(CharSequence s) return true iff the passeed charSequence is avilabe in that particular string .treat new operator obj and literal obj as same
		String ss = new String("Mukt");
		System.out.println("contains method  result :- " +s.contains(ss)); // it will return true
		System.out.println("contains method  result :- " +s.contains("MukT")); // it will return false ->case sensitive
		System.out.println("contains method  result :- " +s.contains("tkuM")); // it will return false --> order maintain
		
		//boolean contentEquals(CharSequence s) 
		System.out.println("contentEquals method result :- "+s.contentEquals("Mukteshwar")); //it will return true
		System.out.println("contentEquals method result :- "+s.contentEquals("Mukt")); //it will return false all string should be same with case
		System.out.println("contentEquals method result :- "+s.contentEquals("mukteshwar")); //it will return false --> case 
		
		
		//static String copyValueOf(Char[] ch)
		char[] ch = {'a','b','c','d','e','f','g'};
		System.out.println("copyValueOf method result :- "+s.copyValueOf(ch)); // o/p --> abcdefg
		//static String copyValueOf(Char[] ch, int offset , int count)
		System.out.println("copyValueOf method result :- "+s.copyValueOf(ch,2,4)); // cdef
		
		//boolean equals(Object obj) ; return true if both are same object contentwise otherwise return false
		System.out.println("equals method result :- "+s.equals("Mukteshwar")); //true
		System.out.println("equals method result :- "+s.equals("mukteshwar")); //false
		
		//byte[] getBytes() it will return byte[]
		
		byte[] b = s.getBytes();
		for(byte bt : b)
		{
			System.out.println(bt); //print ascii values of that particular char
			System.out.println((char)bt);
		}
		
		System.out.println("getBytes method result :- "+s.getBytes()); //return byte[]
		
		//int indexOf(char ch) ; return index of that specified character
		System.out.println("indexOf method result :- "+s.indexOf('a')); //return index --> 8 if u pass char which is not present in that string it won't be throw any exception it will return insertion point in negative 
		System.out.println("indexOf method result :- "+s.indexOf('u',2)); //it will return index but from our specified index onward --> it will return -1 even u present in 1 position
		
		
		//String intern() ; 
		String sss = new String("Mukteshwar");
		String k = sss.intern(); //if we change some code of this line like this --> String k = sss; then following k == s will be false
		System.out.println(k == s);
		System.out.println("intern method result :- "+s.intern());	
		
		//String replace(char oldChar, char newChar)
		System.out.println("replace method result :- "+s.replace('w', 'o'));	//Mukteshoar
		System.out.println("replace method result :- "+s.replace("Muk", "Venka"));	//Venkateshwar
		
		//String replaceAll(String regex, String replacement)
		System.out.println("replaceAll method result :- "+s.replaceAll("Muk", "Venka"));	//Venkateshwar but here first argument should be regular expression
		
		//String[] split(String regex)
		String s1 = "Mukteshwar Ramdas Fadtare Nagapur MIDC";
		String[] sr = s1.split(" "); // it will store Mu and teshwar
		for(String strarr: sr)
		{
			System.out.println(strarr); // 
		}
		
		System.out.println("split method result :- "+s.split(" "));
		
		String[] sr1 = s1.split(" ",2);
		for(String strarr: sr)
		{
			System.out.println(strarr); // 
		}
		
		//CharSequence subSequence(int biginindex,int endindex);
		
		CharSequence sd = s.subSequence(2, 4);
		System.out.println("CharSequence :- "+sd);
		System.out.println("subSequence method result :- "+s.subSequence(2, 4)); //kt
		
		//String subString(int biginindex);
		System.out.println("subString method result :- "+s.substring(4)); //eshwar
		System.out.println("subString method result :- "+s.substring(4,6)); //es
		
		//String trim();
		String m = "   My name is xyz     ";
		System.out.println("Original string :- "+m);
		System.out.println("After trimming:- "+m.trim());
		
		//String valueOf(xx);
		
		System.out.println("valueOf method result :- "+s.valueOf(10.1)); //return 10.1 here we passed double same we can try with char,char[],boolean,float,int,long
		
		char[] ch1 = {'d','d','f','h'};
		
		System.out.println("valueOf method result with char[] :- "+s.valueOf(ch1));
	}
	
	
	
	
}
