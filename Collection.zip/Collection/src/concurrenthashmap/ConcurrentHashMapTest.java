package concurrenthashmap;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ConcurrentHashMapTest {

	static Map<String, Long> orders = new ConcurrentHashMap<>();

	static void processOrders() {
		for (String city : orders.keySet()) {
			for (int i = 0; i < 50; i++) {
				Long oldOrder = orders.get(city);
				orders.put(city, oldOrder + 1);
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		orders.put("Bombay", 0l);
		orders.put("Delhi", 0l);
		orders.put("London", 0l);
		orders.put("Bejing", 0l);

		ExecutorService service = Executors.newFixedThreadPool(2);
		service.submit(ConcurrentHashMapTest::processOrders);
		service.submit(ConcurrentHashMapTest::processOrders);
		
		System.out.println(orders);
		
		service.awaitTermination(5, TimeUnit.SECONDS);
		service.shutdown();
	}
}