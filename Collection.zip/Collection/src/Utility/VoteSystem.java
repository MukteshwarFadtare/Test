package Utility;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

public class VoteSystem {

	// using import statement (voting system) return winner
	// String[] strArray = { "abc", "def", "mno", "xyz", "pqr", "xyz","xyz" };
	public static HashMap winner(String[] s) {
		HashMap map = new HashMap();

		for (String string : s) {

			if (string != null) {

				if (map.containsKey(string)) {
					int count = (int) map.get(string);

					map.put(string, count + 1);

				} else {
					map.put(string, 1);
				}
			}

		}

		return map;

	}

	public static void main(String[] args) {

		String[] strArray = { "a", "c", "d", "a", "d", "d", "a" };

		//System.out.println(winner(strArray));
		
		HashMap map = winner(strArray);
		
		TreeSet<String> ts =  (TreeSet) map.keySet();
		String winner="";
		int highvote=0;
		
		TreeSet<Integer> votes = new TreeSet<>(); 
		
		for (String key : ts) {
			votes.add((Integer) map.get(key));
			
		
			if((int)map.get(key) > highvote)
			{
				winner = key;
				highvote = (int)map.get(key);
			}
			
		}
		System.out.println("winner is :- "+winner);
		
			
		
	}

}
