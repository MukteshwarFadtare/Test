package Utility;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class CountWorldFromString {

	public static int getCount(char c, String s) {
		int count = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == c) {
				count++;
			}
		}

		return count;
	}

	public static void main(String[] args) {
/*
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter String...");

		String s = sc.nextLine();

		System.out.println("Enetr Character for get count...");

		char c = sc.next().charAt(0);

		System.out.println(getCount(c, s));
		
		*/
		HashMap hm = getCharCount("fadtaraae");
		
		Set<Character> keys = hm.keySet();
		
		for (Character key : keys) {
		
			System.out.println("Character :- "+key+ " and its count :- "+hm.get(key));
		}
		

	}

	public static HashMap getCharCount(String s) {
		HashMap hm = new HashMap();

		if (s != null) {
			char[] ch = s.toCharArray();
			
			for (char c : ch) {
				
				if (hm.containsKey(c)) {
					int  k = (int)hm.get(c);
					hm.put(c,k+1);
				} else {
					hm.put(c, 1);
				}
			}

		}
		return hm;

	}

}
