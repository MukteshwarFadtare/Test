package Utility;

import java.util.Scanner;

public class CheckMobileNumber {
	    public static void main(String[] args)
	    {
	        System.out.println("Enter your mobile number");
	 
	        while(true)
	        {
	        Scanner sc = new Scanner(System.in);
	 
	        String input = sc.next();
	        
	        System.out.println("Input :-  "+input+"  lenth :- "+input.length());
	 
	        if(MobileNumberUtility.numberOrNot(input) && (input.length() == 10))
	        {
	            System.out.println("Good!!! You have entered valid mobile number");
	        }
	        else
	        {
	            System.out.println("Sorry!!!! You have entered invalid mobile number. Try again...");
	        }
	        }
	    }
	}