package Utility;

public class MobileNumberUtility {
	static boolean numberOrNot(String input)
    {
        try
        {
        	Long.parseLong(input);
           // Integer.parseInt(input);
        }
        catch(NumberFormatException ex)
        {
        	System.out.println("error occured :- "+ex.getMessage());
        	
            return false;
        }
        return true;
    }

}


