package NavigableSet;

import java.util.TreeSet;
import java.util.NavigableSet;
import java.util.SortedSet;


/*if we want to represent group of individual objects without duplicates according to some sorting order then we should go for SortedSet*/

public class NavigableSetDemo {
	public static void main(String[] args) {

		
	NavigableSet s = new TreeSet();
	
	s.add(1);
	s.add(2);
	s.add(3);
	s.add(4);
	s.add(5);
	s.add(6);
	s.add(7);
	s.add(8);
	s.add(9);
	s.add(10);
	
	System.out.println("Floor Method of NavigableSet :- "+s.floor(15)); //it will return value which is <= 15 ie. = 10
	System.out.println("lower Method of NavigableSet :- "+s.lower(5)); //it will return highest element which is < 5 ie. = 4
	System.out.println("Ceiling Method of NavigableSet :- "+s.ceiling(5)); //it will return Lowest element which is >= 5 ie. = 5 if we comment 5 so it will return 6
	
	System.out.println("Higher Method of NavigableSet :- "+s.higher(5)); //it will return lowest element which is > 5 ie. = 6
	System.out.println("Pollfirst Method of NavigableSet :- "+s.pollFirst()); //it will remove & return first element
	System.out.println("PollLast Method of NavigableSet :- "+s.pollLast()); //it will remove & return Last element
	
	System.out.println("Descending Method of NavigableSet :- "+s.descendingSet()); //it will reverse the treeset
	
	
	}

}
