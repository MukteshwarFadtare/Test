package TreeSet;

import java.util.Comparator;

public class StudentComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		
		Student std1 = (Student)obj1;
		Student std2 = (Student)obj2;
		
		if(std1.rno == std2.rno)
		{
			return 0;
		}
		else
		{
		return (int) (std2.per - std1.per);
		}
	}
	
	

}
