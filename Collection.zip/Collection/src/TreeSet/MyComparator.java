package TreeSet;

import java.util.Comparator;

public class MyComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		
		//For String 
		/*String str1 = (String) obj1;
		String str2 = (String) obj2;
				
		return str2.compareTo(str1); // DESCENDING ORDER
		return str1.compareTo(str2); // ASCENDING ORDER
		*/
		
		//for Integer
		Integer it1 = (Integer)obj1;
		Integer it2 = (Integer)obj2;
		
		//return it1.compareTo(it2); ASCENDING ORDER
		//return -it1.compareTo(it2); // Descending order
		//return -it2.compareTo(it1);//ASCENDING ORDER
		
		return it2.compareTo(it1);//Descending order
	}
	
	

}
