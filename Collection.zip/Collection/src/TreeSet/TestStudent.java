package TreeSet;

import java.util.TreeSet;

public class TestStudent {
	public static void main(String[] args) {
		
		TreeSet t = new TreeSet(new StudentComparator());
		
		t.add(new Student(101,"SHAN",75));
		t.add(new Student(102,"DK",65));
		t.add(new Student(101,"SHAN",85));
		t.add(new Student(103,"MRF",63));
		
		System.out.println(t);
		
	}

}
