package TreeSet;

import java.util.TreeSet;

public class ComparableDemo {

	public static void main(String[] args) {
		
	
	TreeSet t = new TreeSet();
	
	System.out.println("A".compareTo("Z")); // -1
	
	System.out.println("Z".compareTo("A")); // 1
	
	System.out.println("A".compareTo("A")); // 0
	
/*	//internally TreeSet use comparable 
	comparable has only one method that is :-
	
	public int compareTo(Object o);
	
		this method return 3 values :- 
				exp :- obj1.caompareTo(obj2);
	
				if obj1 is less than object 2 :- return -1
				if obj1 is greater than object 2 :- return 1
				if both are equal :- return 0*/
}
}
