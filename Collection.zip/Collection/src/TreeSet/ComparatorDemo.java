package TreeSet;

import java.util.TreeSet;

public class ComparatorDemo {
	
	public static void main(String[] args) {
		
		TreeSet s = new TreeSet(new MyComparator());
		
		
		//for string 
		/*s.add("X");
		
		s.add("A");
		
		s.add("K");
		
		*/
		
		//for integer
		
		s.add(15);
		s.add(5);
		s.add(115);
		s.add(105);
		
		System.out.println(s);
		
	}

}
