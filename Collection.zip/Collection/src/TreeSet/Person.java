package TreeSet;

import java.util.TreeSet;

public class Person implements Comparable{

	
	private int pid;
	private String pname;
	
	Person(int pid,String pname)
	{
		this.pid = pid;
		this.pname = pname; 
	}
	
	/*public void display() {
		
		System.out.println("Person id :- ");

	}*/
	
	
	
	@Override
	public int compareTo(Object o) {
		
		Person p = (Person) o;
		int ob1 = p.pid;
		int ob = this.pid;
			if(ob < ob1)
			{
				return -1;
			}
			else if(ob > ob1)
			{
				return 1;
			}
			else
			{
		return 0;
			}
	}
	
	
	
	public static void main(String[] args) {
		
		
		Person p = new Person(101, "MRF");
		Person p1 = new Person(99, "MRF");
		Person p2 = new Person(187, "MRF");
		Person p3 = new Person(78, "MRF");
		TreeSet<Person> tr = new TreeSet<>();
		
		tr.add(p);
		tr.add(p1);
		tr.add(p2);
		tr.add(p3);
		
		System.out.println(tr);
		
		for (Person person : tr) {
			
			System.out.println("Person Id :  "+person.pid);
			
		}
		
		
	}


}
