package TreeSet;

import java.util.TreeSet;

public class TreeSetDemo {
	public static void main(String[] args) {
		
		TreeSet t = new TreeSet(new MyComparator());
		
		/*System.out.println(t.add("A"));
		System.out.println(t.add("Z"));
		System.out.println(t.add("C"));
		System.out.println(t.add("K"));
		System.out.println(t.add("F"));
		System.out.println(t.add("A"));
		*/
		//if we are trying to add null value at very first in treeset its fine but after that we cant add more values bcoz as soon as we get CE error
//		t.add(null);
		
		//our added object should be comparable if not we will get following error.
		
		/*t.add(new StringBuffer("A"));
		t.add(new StringBuffer("Z"));
		*/
		
		//heterogeneous objects are not allowed -->  java.lang.ClassCastException: java.lang.Integer cannot be cast to java.lang.String
		
		//if we use comparator then we can use heterogeneous objects
		t.add(101);
		t.add(102);
		//t.add("MRF");
		
		System.out.println(t);
		
		//Exception in thread "main" java.lang.ClassCastException: java.lang.StringBuffer cannot be cast to java.lang.Comparable
		

	}

}
