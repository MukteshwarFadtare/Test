package TreeSet;

public class Student {
	
	int rno;
	private String name;
	double per;
	
	Student(int rno, String name,double per)
	{
		this.rno = rno;
		this.name = name;
		this.per = per;
	}

	public String toString()
	{
		return "Roll no :- "+rno+"  Name :-  "+name+" Percentage :-  "+per;
	}
}
