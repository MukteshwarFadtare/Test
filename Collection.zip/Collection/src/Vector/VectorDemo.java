package Vector;

import java.util.Vector;

public class VectorDemo {
	public static void main(String[] args) {
		
	Vector<Integer> v = new Vector<Integer>();
	
	for(int i=0; i<=10; i++){
	v.add(i);
	}
	//if we remove above comment we will get 20 capacity of vector
	
	System.out.println(v.capacity()); //10
	System.out.println("before using setSize() ");
	System.out.println(v);
	System.out.println("AFter setting custom size 15");
	//v.setSize(15);//  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, null, null, null, null]
	v.setSize(5); // [0, 1, 2, 3, 4]
	/*if we set size greater than original it will add null for extra
	elements and if we set less than original then it will remove particular elements from last
	*/
	System.out.println(v);
	}

}
