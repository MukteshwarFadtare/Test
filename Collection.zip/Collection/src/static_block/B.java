package static_block;

class B extends A
{
    static
    {
        i = --i - i--;
        System.out.println("B SIB :- "+i);
    }
 
    {
        i = ++i + i++;
        System.out.println("B IIB :- "+i);
        
    }
}