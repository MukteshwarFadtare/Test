package static_block;

class A
{
    static int i = 1111;
 
    static
    {
        i = i-- - --i;
        System.out.println("A SIB :- "+i);
    }
 
    {
        i = i++ + ++i;
        System.out.println("A IIB :- "+i);
    }
}