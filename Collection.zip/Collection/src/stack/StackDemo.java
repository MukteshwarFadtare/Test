package stack;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		
		Stack s = new Stack();
		for(int i=0; i<=10; i++){
			s.push(i);
			}
		
	//System.out.println(" Pop method :- "+s.pop());//it retuern top element(10) and also remove it
	System.out.println(" Peek method :- "+s.peek());// it will return top element only(10)
	System.out.println(" Search method :- "+s.search(8)); //it object available it will return 1 oterwise -1
	System.out.println(" Empty method :- "+s.empty());
		
	System.out.println(s.capacity()); //same like vector
		
		
	}
}
