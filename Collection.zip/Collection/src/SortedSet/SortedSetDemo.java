package SortedSet;

import java.util.TreeSet;
import java.util.SortedSet;


/*if we want to represent group of individual objects without duplicates according to some sorting order then we should go for SortedSet*/

public class SortedSetDemo {
	public static void main(String[] args) {

		
	SortedSet s = new TreeSet();
	
	s.add(1);
	s.add(2);
	s.add(3);
	s.add(4);
	s.add(5);
	s.add(6);
	s.add(7);
	s.add(8);
	s.add(9);
	s.add(10);
	
	System.out.println("First Method of SortedSet :- "+s.first());
	System.out.println("Last Method of SortedSet :- "+s.last());
	System.out.println("Headset Method of SortedSet :- "+s.headSet(5));
	System.out.println("Tailset Method of SortedSet :- "+s.tailSet(5));
	System.out.println("subset Method of SortedSet :- "+s.subSet(2, 6));
	
	
	
		
	}

}
