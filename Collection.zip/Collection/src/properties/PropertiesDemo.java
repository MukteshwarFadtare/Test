package properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesDemo {
	public static void main(String[] args) throws IOException {

		Properties p = new Properties();
		
		FileInputStream fis = new FileInputStream("F:/myProperties.properties");
		
		p.load(fis);
		p.setProperty("myName", "MUkteshwar");
		
		FileOutputStream fos = new FileOutputStream("F:/myProperties.properties");
		
		p.store(fos, "Updated by MRF");
		
		//System.out.println(p.keySet()); //[password, url, driver, username]
		//System.out.println(p.getProperty("password"));
		System.out.println(p);//{password=root, url=jdbc:mysql://localhost:3306/test, driver=com.mysql.jdbc.Driver, username=root}
		
		
	}

}
