package InterviewPrograms;

public class WrapperInteger {

	public static void main(String[] args) {
		Integer i1 = 127;

		Integer i2 = 127;

		System.out.println(i1 == i2); //true

		Integer i3 = 129; 

		Integer i4 = 129;

		System.out.println(i3 == i4); //false
		
		Integer n = new Integer(127);
		Integer n1 = new Integer(127);
		
		System.out.println(n==n1); //false
		
	}
}
