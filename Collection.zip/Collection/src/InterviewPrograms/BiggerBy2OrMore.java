package InterviewPrograms;

import java.util.Scanner;

/*3) There are two numbers �a� and �b�. Write a java program which should print �a� if �a� is bigger than �b� by 2 
or more or should print �b� if �b� is bigger than �a� by 2 or more. Otherwise, it should print �INCONCLUSIVE�?
*/
public class BiggerBy2OrMore {
	
	public static void main(String[] args) {
		
		System.out.println("Enter First No :- ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		System.out.println("Enter Second No :- ");
		
		int n1 = sc.nextInt();
		
		if(n > n1 && n - n1 >= 2)
		{
			System.out.println(n);
		}
		else if(n1 > n && n1 - n >= 2)
		{
			System.out.println(n1);
		}
		else
		{
			System.out.println("INCONCLUSIVE");
		}
	
	}
	
	
	

}
