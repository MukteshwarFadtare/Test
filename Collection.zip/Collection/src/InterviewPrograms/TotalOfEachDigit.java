package InterviewPrograms;

public class TotalOfEachDigit {

	
	public static int getTotal(int n)
	{
		int tot=0,rem;
		
		while(n != 0)
		{
			rem = n%10;
			n = n/10;
			tot+= rem;
		}
		
		return tot;
	}
	
	public static void main(String[] args) {
		
		int tot = getTotal(4578);
		
		System.out.println(tot);
	}
	
}
