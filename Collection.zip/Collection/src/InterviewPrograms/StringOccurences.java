package InterviewPrograms;

import java.util.HashMap;
import java.util.Set;

public class StringOccurences {
	
	public static HashMap getStringOccr(String s)
	{
		HashMap hs = new HashMap();
		char[] ch = s.toCharArray();
		for(char c : ch)
		{
			if(hs.containsKey(c))
			{
				int k = (int)hs.get(c);
				hs.put(c,k+1);
			}
			else
			{
				hs.put(c, 1);
			}
		}
		
	
	return hs;
	}
	
	public static void main(String[] args) {
		
		String s = "SachinTendul" ;
		
		HashMap hs = getStringOccr(s);
		
		
		Set key = hs.keySet();
		
		for(Object c : key)
		{
			char k = (char)c;
			System.out.println("Keys :- "+k+ " number of times i string :- "+hs.get(k));
			
		}
		
	}

}
