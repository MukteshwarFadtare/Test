package InterviewPrograms;

public class String_AnagramWithoutImport {

	public static void isAnagram(String s1, String s2) {
		String cp1 = s1.replaceAll("\\s", "");
		String cp2 = s2.replaceAll("\\s", "");

		boolean status = false, flag = false;
		;
		if (cp1.length() == cp2.length()) {
			char[] ch1 = cp1.toLowerCase().toCharArray();
			char[] ch2 = cp2.toLowerCase().toCharArray();

			for (int i = 0; i < ch1.length; i++) {

				flag = false;
				for (int j = 0; j < ch2.length; j++) {
					if (ch2[j] == ch1[i]) {
						flag = true;
					}
				}
				if (flag != false) {
					status = true;
				} else {
					status = false;
					break;
				}

			}

		} else {
			status = false;
		}
		if (status) {
			System.out.println("Strings are anagram....");
		} else {
			System.out.println("Strings are not anagram....");
		}

	}

	public static void main(String[] args) {

		isAnagram("abcd", "cdba");
	}

}
