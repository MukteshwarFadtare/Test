package InterviewPrograms;

public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		
		String s = "Fadtare Mukteshwar Ramdas	Nagapur Ahmednagar	MH";
		String s3="";
		//using split method
		
		/*String[] split = s.split("\\s");
		for(String s2 : split)
		{
			//System.out.println(s2);
			s3 +=s2;
		}
		
		System.out.println("Without whitespaces string :- "+s3);*/
		
		//using replaceAll() method
		/*s3 = s.replaceAll("\\s", "");
		System.out.println(s3);*/
		
		//using stringBuffer object and charAt() method of string
		
		StringBuffer sb = new StringBuffer();
		
		for(int i=0; i<s.length();i++)
		{
			if(s.charAt(i) != ' ' && s.charAt(i) != '\t')
			{
				sb.append(s.charAt(i));
			}
		}
		
		System.out.println(sb);
		
	}
	
}
