package InterviewPrograms;

import java.util.Arrays;
/*
What Is Anagram?

Two strings are called anagrams if they contain same set of characters but in different order.
For example, �Dormitory � Dirty Room�, �keep � peek�,  �School Master � The Classroom� are some anagrams.

*/

public class String_Anagram {

	public static void isAnagram(String s, String s1) {
		// copy original string in new variable without whitespace
		String copy1 = s.replaceAll("\\s", "");
		String copy2 = s1.replaceAll("\\s", "");

		boolean status = true;

		if (copy1.length() == copy2.length())

		{
			char[] ch1 = copy1.toLowerCase().toCharArray();
			char[] ch2 = copy2.toLowerCase().toCharArray();

			// sort array using Arrays method
			Arrays.sort(ch1);
			Arrays.sort(ch2);

			// compare equality of two arrays
			status = Arrays.equals(ch1, ch2);
		}
		else
		{
			status=false;
		}
		
		if (status) {
			System.out.println("Strings are Anagram....");
		} else {
			System.out.println("Strings are not Anagram...");
		}

	}
	public static void main(String[] args) {
		
		isAnagram("MY team", "mateMY");
		
	}

}
