package InterviewPrograms;

public class SecondHighestFromArray {
	
	/*public static int get2ndHigh(int[] arr)
	{
		int firstHigh,secondHigh;
		if(arr[0] > arr[1])
		{
			firstHigh = arr[0];
			secondHigh = arr[1];
		}
		else
		{
			firstHigh = arr[1];
			secondHigh = arr[0];
			
		}
		
		for(int i = 2; i< arr.length; i++)
		{
			if(arr[i] > firstHigh)
			{
				secondHigh = firstHigh;
				firstHigh = arr[i];
			}
			else if(arr[i] > secondHigh && arr[i] < firstHigh)
			{
				secondHigh = arr[i];
			}
				
		}
		
		return secondHigh;
	}
	*/
	public static void main(String[] args) {
		
		int[] arr1 = {10,45,1,54,46,24};
		String s = "MRF";
	System.out.println(s.contains("k"));
		
		System.out.println("Second Highest From 1 Array :- "+get2ndHigh(arr1));
		
	}

	private static int get2ndHigh(int[] arr1) {
		
		int[] copy = arr1;
		int firstHigh,secondHigh;
		
		if(copy[0] > copy[1])
		{
			firstHigh = copy[0];
			secondHigh = copy[1];
		}
		else {
			firstHigh = copy[1];
			secondHigh = copy[0];
		}
		
		
		for(int i = 0; i< copy.length - 1 ; i++)
		{
			
			if(copy[i] > firstHigh)
			{
				secondHigh = firstHigh;
				firstHigh = copy[i];
				
			}
			else if(copy[i] > secondHigh )
			{
				secondHigh = copy[i];
			}
			
		}
		

	
	return secondHigh;
	
	}

}
