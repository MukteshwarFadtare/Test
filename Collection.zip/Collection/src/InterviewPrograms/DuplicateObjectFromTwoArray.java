package InterviewPrograms;


import java.util.Arrays;
import java.util.HashSet;
import java.util.List;


public class DuplicateObjectFromTwoArray {
	
	//there are 2 methods for achieve this task
	
	public static void main(String[] args) {
		
		String[] s = {"MRF","SHAN","DK"};
		String[] s1 = {"MRF","SHAN","GAURAV"};
		
		//using hashset 
	/*	HashSet set = new HashSet();
		
		for(int i=0; i<s.length;i++)
		{
			for(int j =0; j< s1.length; j++)
			{
				if(s1[j].equals(s[i]))
				{
					set.add(s[i]);
				}
			}
		}
		
		System.out.println(set);*/
		
		//using retainall method
		
		//first of all we have to convert array into Hashset
		
		HashSet h = new HashSet(Arrays.asList(s));
		
		HashSet h1 = new HashSet(Arrays.asList(s1));
		
		int [] a= {1};
		float [] f = {1};
		double[] d= {1};
		Arrays.asList(a);
		Arrays.asList(f);
		Arrays.asList(d);
		
		
		
		System.out.println("Before retain method :- "+h);

		h.retainAll(h1);
		
		System.out.println("After retain methid :- "+h);
		
		
		
	}

}
