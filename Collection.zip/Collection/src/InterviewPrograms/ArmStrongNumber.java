package InterviewPrograms;

public class ArmStrongNumber {

	/*public static void checkArmStrong(int num) {
		int copy = num;
		int len = String.valueOf(num).length();
		int sum = 0;
		while (copy != 0)
		{
			int lastsum = 1;
			int last= copy%10;
			for(int i = 0; i< len; i++)
			{
				lastsum = lastsum*last;
			}
			sum = sum+lastsum;
			copy = copy/10;
		}
		if(sum == num)
		{
			System.out.println("No is armstrong..");
		}
		else
		{
			System.out.println("No is not armstrong");
		}
	}
	
	*/
	
	
	
	
	
	
	public static void main(String[] args) {
		
		checkArmStrong(153);
	}

	private static void checkArmStrong(int i) {
		
		int mynum = i,sum = 0;
		int len = Integer.toString(mynum).length();
		
		while(mynum != 0)
		{
			
			int lastsum = 1;
			int last = mynum %10;
			
			for(int k=0;k<len;k++)
			{
				lastsum = lastsum*last;
			}
			
			sum = sum+lastsum;
			mynum = mynum /10;
			
		}
		
		if(sum == i)
		{
			System.out.println("number is armstrong....");
		}
		else
		{
			System.out.println("number is not armstrong....");
		}
	}

}
