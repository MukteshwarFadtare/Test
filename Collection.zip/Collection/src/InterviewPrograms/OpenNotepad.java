package InterviewPrograms;

import java.io.IOException;

public class OpenNotepad {
	public static void main(String[] args) throws InterruptedException {
		try {

			// Runtime.getRuntime().exec("notepad.exe");//it will open new
			// instance of notepad

			// open specific file in notepad
			//Runtime.getRuntime().exec("notepad H:\\sample.txt");

			// open a browser (Chrome)
			// Runtime.getRuntime().exec("C:\\Program Files
			// (x86)\\Google\\Chrome\\Application\\chrome.exe");

			// open browser with specified website
			/*
			 * String[] s = new String[] {
			 * "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
			 * , "http://javaconceptoftheday.com/" };
			 * Runtime.getRuntime().exec(s);
			 * 
			 * 
			 */

			// play a video/audio in vlc

			//String[] s = new String[] {"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe", "G:\\Video Songs\\Bollywood\\DTBina.mp4"}; // for video
			String[] s = new String[] {"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe", "G:\\MRF music\\mp3\\0129 Don.mp3"};//for audio
			Process process = Runtime.getRuntime().exec(s);
			
			Thread.sleep(10000);
			
			process.destroy();
			

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}


