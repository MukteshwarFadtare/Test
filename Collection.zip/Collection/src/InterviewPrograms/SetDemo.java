package InterviewPrograms;

import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo {
	
	public static void main(String[] args) {
		
		SortedSet s = new TreeSet();
		int count=0;
		s.add(1);
		s.add(2);
		s.add(3);
		s.add(4);
		s.add(5);
		s.add(6);
		s.add(7);
		s.add(8);
		s.add(9);
		s.add(10);
		
		/*
		int size = s.size();
		if(size >= 8)
		{
			for(Object n: s)
			{
				count++;
				if(count == 8)
				{
					System.out.println(n);
				}
			}
		}*/
		System.out.println("5th no element :- "+s.subSet(5, 6));
		System.out.println("Last element :- "+s.last());
		System.out.println("First element :- "+s.first());
	}

}
