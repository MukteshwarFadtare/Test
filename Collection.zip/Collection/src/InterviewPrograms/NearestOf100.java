package InterviewPrograms;

import java.util.Scanner;

//2) Write a Java program to find out the nearest number to 100 of the given two numbers?
public class NearestOf100 {
	
	public static int nearestOf100(int n1,int n2)
	{
	
		int diff1 = 100 - n1;
		int diff2 = 100 - n2;
		if(diff1 < diff2)
		{
		return n1;	
		}
		else
		{
			return n2;
		}
		
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter First No :- ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		System.out.println("Enter Second No :- ");
		
		int n1 = sc.nextInt();
		
		System.out.println("Nearest of 100 no is:- "+nearestOf100(n, n1));
	}

}
