package InterviewPrograms;

public class ReverseString {
	
	public static String getReverse(String s )
	{
		String s1 = "";
		//using toCharArray() method
		/*char[] c = s.toCharArray();
		int size = c.length;
		for(int i =size-1; i >= 0; i-- )
		{
			s1 +=c[i]; 
		}*/
		
		//using charAt() method
		
		/*for(int i = s.length() - 1;i>=0;i--)
		{
			s1 +=s.charAt(i);
		}
*/		
		//using StringBuffer object
		
		StringBuffer sb = new StringBuffer(s);
		sb.reverse();
		s1 = new String(sb);
		
		
		return s1;
	}
	public static void main(String[] args) {
		System.out.println("main start....");
		
		System.out.println(getReverse("Ramdas"));
		
		System.out.println("main end...");
		
	}

}
