package InterviewPrograms;

import java.util.Scanner;

public class NumberIsBinaryOrNot {

	public static void isBinary(int number) {
		int copy = number;
		boolean isbinary = true;
		while (copy != 0) {
			int last = copy % 10;
			if (last > 1) {
				isbinary = false;
				break;
			} else {
				copy = copy / 10;
			}

		}
		if(isbinary)
		{
			System.out.println("Number is Binary");
		}
		else
		{
			System.out.println("Number is not binary");
		}

	}
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Main started....");
		while(true)
		{
		System.out.println("Enter 1 start and 0 for exit");
		int n = s.nextInt();
		if(n == 0)
		{
			System.exit(0);
		}
		else
		{
		System.out.println("Enter No for check whether it is binary or not ?");
			
			int nn = s.nextInt();
			isBinary(nn);
	
		}
		
		}
		
		
	}

}
