package InterviewPrograms;

public class ThrowDemo {
	
	int n,k;
	
	public static float getDiv(int n,int k)
	{
		if(k<0)
		{
			throw new ArithmeticException();
		}
		
			return n/k;
	}
	public static void main(String[] args) {
		
		try
		{
		getDiv(12, 0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("exception occured");
		}
	}

}
