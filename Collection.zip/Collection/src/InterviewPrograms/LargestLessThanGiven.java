package InterviewPrograms;

//here condition is user will send a digit with no that should not contain in less number and output no should be Largest Less of given number
public class LargestLessThanGiven {
	
	public static int getLarge(int no,int digit)
	{
		char dig = Integer.toString(digit).charAt(0);
		no--;
		while(no != 0)
		{
			if(Integer.toString(no).indexOf(dig) == -1)
			{
				return no;
			}
			else
			{
				no--;
			}
		}
		
		
		return no;
	}
	
	public static void main(String[] args) {
		
		System.out.println("main start...");
		
		System.out.println(getLarge(1452,4));
		
	}

}
