package InterviewPrograms;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatDemo {

	public static void main(String[] args) {
		
		Date date = new Date();
		
		 SimpleDateFormat formatter = new SimpleDateFormat("dd MM YYYY");
		 
	        System.out.println(formatter.format(date));
	}
	
}
