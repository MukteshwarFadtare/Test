package InterviewPrograms;

import java.util.HashMap;
import java.util.Set;

public class DuplicateCharactersInString {
	
public static HashMap getDup(String s)
{
	HashMap<Character,Integer> hs = new HashMap<Character,Integer>();
	char[] ch = s.toCharArray();
	for(char c : ch)
	{
		if(hs.containsKey(c))
		{
			int k = (int)hs.get(c);
			hs.put(c,k+1);
		}
		else
		{
			hs.put(c, 1);
		}
	}
	
	return hs;
}
	
	public static void main(String[] args) {
		
		System.out.println("main started....");
		String s = "Mukteshwar Ramdas";
		
		HashMap<Character,Integer> hs = getDup(s);
		
		Set<Character> keys = hs.keySet();
		
		for(char c:keys)
		{
			if(hs.get(c) > 1)
			{
				System.out.println("This '"+c+ "'Char Repeat :- "+hs.get(c));
			}
		}
		
	}

}
