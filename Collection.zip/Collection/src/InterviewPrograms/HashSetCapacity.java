package InterviewPrograms;

import java.util.Arrays;
import java.util.HashSet;

public class HashSetCapacity {
	
	public static void main(String[] args) {
		
		HashSet hs = new HashSet();
		hs.add(15);
		System.out.println("HashSet capacity :- "+hs);
		
		String s ="MRF";
		char[] ch = s.toCharArray();
		char[] ch1 = new char[ch.length];
		int len = ch.length,count=0;;
		StringBuffer sb = new StringBuffer();
		for(int i=len-1; i>=0; i--)
		{
			ch1[count] = ch[i];
			count++;
			sb.append(ch[i]);
			System.out.println(ch[i]);
		}
		
		//convert stringBuffer object into String
		String ss = new String(sb);
		
		System.out.println(ss.toString()+" ToString and Hashcode is :- "+ss.hashCode());
		
	}

}
