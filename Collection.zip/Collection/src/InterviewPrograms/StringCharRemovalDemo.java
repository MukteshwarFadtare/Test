package InterviewPrograms;

import java.util.Scanner;

public class StringCharRemovalDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		while (true) {

			System.out.println("Please enter string : ");

			String str = sc.nextLine();

			System.out.println(getReducedString(str));
		}

	}

	private static String getReducedString(String str) {
		StringBuffer sb = new StringBuffer(str);

		int preIndex = 0;
		for (int i = 1; i < sb.length(); i++) {
			if (sb.charAt(preIndex) == sb.charAt(i)) {
				sb.delete(preIndex, i + 1);
				preIndex = 0;
				i = 0;
			}
			System.out.println("Now sb : " + sb);
			preIndex = i;

		}
		String s = new String(sb);

		return s;
	}

}
