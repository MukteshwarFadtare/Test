package InterviewPrograms;

public class ImmutableClass {

	int i;
	public ImmutableClass(int i)
	{
		this.i = i;
	}
	
	public final ImmutableClass modify(int j)
	{
		if(j == this.i)
		{
			return this;
		}
		else
		{
		return	new ImmutableClass(j);
		}
	}
	
	public static void main(String[] args) {
		
		ImmutableClass ob = new ImmutableClass(10);
		ImmutableClass ob1 = ob.modify(10);
		
		System.out.println(ob.i);
		System.out.println(ob1.i);
		
		System.out.println(ob == ob1);
		
		/*final StringBuffer sb = new StringBuffer("kumar");
		sb.append("Dusunge");
		sb.delete(0, 6);
		System.out.println(sb);
		*/
		
		//StringBuffer sb = new StringBuffer(); //initial capacity 16
		//StringBuffer sb = new StringBuffer("MRF"); // now become 16 + 3 = 19
		/*StringBuffer sb = new StringBuffer(100); //directly we can define capacity
		System.out.println(sb.capacity());*/
	}
	
}
