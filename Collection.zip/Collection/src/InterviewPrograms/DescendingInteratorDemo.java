package InterviewPrograms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Spliterator;

public class DescendingInteratorDemo {
	
	
	
	public static void main(String[] args) {
		
		LinkedList l = new LinkedList<>();
		
		l.add("MRF");
		l.add("SHAN");
		
		l.add(101);
		l.add("TUSHAR");
		
		l.add("AKSHAY");
		l.add(141);
		
		
		
		Iterator itr = l.descendingIterator();
		
		System.out.println("using descending iterator.....start..");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("using descending iterator.....end...");
		
		
		Iterator itr1 = l.iterator();
		
		System.out.println("using ascending iterator.....start..");
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
		System.out.println("using ascending iterator.....end...");
		
		ListIterator ltr = l.listIterator();
		
		System.out.println("using List iterator.....start..");
		while(ltr.hasNext())
		{
			System.out.println(ltr.next());
		}
		System.out.println("using List iterator.....end...");
		
		
		
		
		
	}
	

}
