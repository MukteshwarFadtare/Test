package InterviewPrograms;

//Java program to check whether one string is rotation of another string.
public class StringRotation {

	public static void main(String[] args) {
		
		String s1 = "fadtareMukteshwar";
		String s2 = "Mukteshwarfadtare";
		
		if(s1.length() != s2.length())
		{
			System.out.println("string is not rotated");
		}
		else
		{
			String s3 = s1+s1;
			if(s3.contains(s2))
			{
				System.out.println("String is rotated..");
			}
			else
			{
				System.out.println("else... conatins");
			}
		}
	}
	
}
