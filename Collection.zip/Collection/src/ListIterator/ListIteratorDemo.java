package ListIterator;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;

public class ListIteratorDemo {
	public static void main(String[] args) {

		LinkedList l = new LinkedList();

		for (int i = 0; i <= 10; i++) {
			l.add(i);
		}

		System.out.println("before size :- " + l.size());

		// iteration forward

		ListIterator ls = l.listIterator();

		while (ls.hasNext()) {

			int n = (int) ls.next();
			System.out.println("forward iteration :- " + n);

			// repace element
			if (n == 4) {
				ls.set(25); // it will replace 25 value against 4
			}

			// add new element
			if (n == 3) {
				ls.add(22); // here linkedlist will add 22 at 4th index
			}

			// remove element
			if (n == 2) {
				ls.remove(); // here 2 number will be deleted from linkedList
			}

			// previous iteration
			if (n == 5) {
				while (ls.hasPrevious()) {
					System.out.println("Backward Iteration :- " + ls.previous());
				}
				break;

			}

		}

		System.out.println("After size :- " + l.size());

	}

}
