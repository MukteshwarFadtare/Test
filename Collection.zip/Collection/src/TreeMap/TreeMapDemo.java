package TreeMap;

import java.util.TreeMap;

public class TreeMapDemo {
	public static void main(String[] args) {

		TreeMap m = new TreeMap(new MyComparator());
		
		m.put(108, "MRF");
		m.put(105, "SHAN");
		m.put(10, "SHAN");
		m.put(05, "SHAN");
		m.put(115, "SHAN");
		m.put("Ss", "DK");
		m.put(2, "DK");
		m.put(6, "DK");
		m.put("DD", "DK");
		System.out.println(m);
		
		
	
	}

}
