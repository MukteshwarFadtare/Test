package TreeMap;

import java.util.Comparator;

public class MyComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
	
	/*if(obj1.getClass().equals("class java.lang.Integer") || obj2.getClass().equals("class java.lang.Integer"))
		{
			if(obj2.getClass().equals("class java.lang.Integer"))
					{
					System.out.println("in int");
					Integer n1 = (Integer)obj1;
					Integer n2 = (Integer)obj2;
					return n1.compareTo(n2);
					}
			return -1;
		}
		else if(obj1.getClass().equals("class java.lang.String") || obj2.getClass().equals("class java.lang.String"))
		{
			return 1;
		}
			*/
		/*if(obj1.getClass().equals("class java.lang.Integer") && obj2.getClass().equals("class java.lang.Integer"))
		{
		
		Integer n1 = (Integer)obj1;
		Integer n2 = (Integer)obj2;
		return n2.compareTo(n1);
		
		}
		else
		{
			return -1;
		}*/
		return 1; //if we direct return 1 statically ,we can preserved insertion order.
	}
	
	

}
