package deadLock;

public class ContractOfEqaulAndHashCode {
	String firstName,lastName;
	int age;
	Object obj;
	
	ContractOfEqaulAndHashCode(String firstName,String lastName,int age)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	
	@Override
    public boolean equals(Object obj)
    {
		ContractOfEqaulAndHashCode person = (ContractOfEqaulAndHashCode) obj;
 
        return this.firstName == person.firstName && this.lastName == person.lastName && this.age == person.age;
    }
	
	public String toString()
	{
	return "FirstName :- "+firstName+ " LastName :- "+lastName+ " Age :- "+age; 
	}
 
	public int hashCode()
	{
		int hashCode = 0;
		hashCode +=firstName.hashCode();
		hashCode +=lastName.hashCode();
		hashCode +=Integer.toString(age).hashCode();
		return hashCode;
	}
	
	
	public static void main(String[] args) {
		
		ContractOfEqaulAndHashCode person = new ContractOfEqaulAndHashCode("MRF","FAD",25);
		ContractOfEqaulAndHashCode person1 = new ContractOfEqaulAndHashCode("MRF","FAD",25);
		
		System.out.println(person.hashCode());
		System.out.println(person1.hashCode());
		
		
		System.out.println("check the 2 objects equality(same content with different address(location) ) :- "+person.equals(person1));
		
		ContractOfEqaulAndHashCode person2 = new ContractOfEqaulAndHashCode("MRF","FAD",26);
		
		
		System.out.println("check the 2 objects equality(different content with different address(location) ) :- "+person.equals(person2));
		System.out.println(person2.hashCode());
		
	}
	

}
