package FLOAT_DOUBLE_METHODS;

public class IsNaNDemo
{
    public static void main(String[] args)
    {
 /*       double d = 0.0/0.0;
 
        System.out.println(Double.isNaN(d));//Output : true
        System.out.println(d);
 
        d = Math.sqrt(-1.2);
 
        System.out.println(Double.isNaN(d));    //Output : true
 
        float f = 0.0f/0.0f;
 
        System.out.println(Float.isNaN(f));            //Output : true
 
        f = 0 * Float.POSITIVE_INFINITY;
 
        System.out.println(Float.isNaN(f)); */         //Output : true
    	
    	float f1 = Float.POSITIVE_INFINITY;
    	float f2 = Float.NEGATIVE_INFINITY;
    	System.out.println(f1);
    	System.out.println(f2);
    }
}