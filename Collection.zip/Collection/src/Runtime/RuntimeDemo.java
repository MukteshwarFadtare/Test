package Runtime;

import java.util.Arrays;
import java.util.Date;

public class RuntimeDemo
{
    public static void main(String[] args)
    {
      
    	System.out.println("Main method start..");
    	
    	
    	Runtime r = Runtime.getRuntime();
    	
    	System.out.println("Total Memory :- "+r.totalMemory());
    	System.out.println("Free Memory :- "+r.freeMemory());
    	
    	for(int i = 0; i< 10000; i++)
    	{
    		Date d = new Date();
    		d = null;
    	}
    	r.gc();
    	
    	System.out.println("AFter r Free Memory :- "+r.freeMemory());
    	
    }
}