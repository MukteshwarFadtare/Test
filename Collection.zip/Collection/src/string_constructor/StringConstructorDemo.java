package string_constructor;

public class StringConstructorDemo {
	
	public static void main(String[] args) {
		
	
	byte[] b = {80,97,108,108,97,118,105};
	
	byte c = (byte) 145;
	//System.out.println(c);
	
	String s = new String(b);
	
	System.out.println(s);
	
/*
	char[] a={'p','a'};
	
	String s1 = new String(a);
	System.out.println(s1);*/
	
}
}
