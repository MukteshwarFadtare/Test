package Map;

import java.util.HashMap;

public class HashMapInternalWorking {
	
	
	public static void main(String[] args) {
		
		System.out.println("main started....");
		HashMap hs = new HashMap();
		
		hs.put(12, "Kumar");
		
		hs.put(13, "Sajan");
		
		hs.put(12, "DK");
		System.out.println(hs);
		System.out.println("main end....");
	}

}
