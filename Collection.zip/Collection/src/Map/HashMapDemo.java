package Map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;


public class HashMapDemo {
	public static void main(String[] args) {

		WeakHashMap m =new WeakHashMap();
		
		m.put("MRF"," java");
		
		System.out.println(m);
		System.gc();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(m);
		
	}

}
