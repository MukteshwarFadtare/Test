package HashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class HashSetDemo {
	public static void main(String[] args) {

		//HashSet internally use HashMap when we call the constructor of HashSet internally it will create new (Backing)object of HashMap.
		//in HashSet class this line is available ==> private transient HashMap<E,Object> map;
		 
		HashSet hs = new HashSet(); // this line HashSet() will create HashMap obj ==> map = new HashMap<>();
		
		hs.add("MRF");
		hs.add("SAJAN");
		/*when we call above add() method internally it will call put() of map ==> 
		public boolean add(E e)
		{
		        return map.put(e, PRESENT)==null; //here our HashSet value set as a key and PRESENT constant as a value 
		}
		*/
		
		hs.remove("SAJAN"); 
		 /*when we call above remove() method it will call remove() method of HashMap
		
		 public boolean remove(Object o)
		 {
		         return map.remove(o)==PRESENT;
		 }*/
		 
		hs.add("Shan");
		hs.add("DK");
	
	System.out.println(hs.add("MRF")); //if we try to add duplicate element it won't give any CE or RE just return "False"
		hs.add(12);
		System.out.println(hs);
		
		
		
		System.out.println(	hs.contains("MRF")); // it will return true if specified object available in HashSet
	
		List l = new ArrayList();
		l.add(101);
		l.add(102);
		l.add(103);
		
		
		hs.addAll(l);
		
		
		System.out.println(hs);
		
	}

}
