package HashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class LinkedHashSetDemo {
	public static void main(String[] args) {

		LinkedHashSet hs = new LinkedHashSet();
		
		hs.add("MRF");
		hs.add("Shan");
		hs.add("DK");
		hs.add("SAJAN");
	System.out.println(hs.add("MRF")); //if we try to add duplicate element it won't give any CE or RE just return "False"
		hs.add(12);
		System.out.println(hs);
		System.out.println(	hs.contains("MRF")); // it will return true if specified object available in HashSet
	
		List l = new ArrayList();
		l.add(101);
		l.add(102);
		l.add(103);
		
		hs.addAll(l);
		
		System.out.println(hs); //because of LinkedHashSet it will follow insertion order
		
	}

}
