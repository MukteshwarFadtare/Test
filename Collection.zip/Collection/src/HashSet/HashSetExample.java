package HashSet;

import java.util.HashSet;

public class HashSetExample {
	
	private int rollNo;
	private String firstName,lastName;
	
	public HashSetExample(int rollNo,String firstName , String lastName) {

		this.rollNo = rollNo;
		this.firstName = firstName;
		this.lastName = lastName;
		
			
	}
	
	public int hashCode()
	{
		return rollNo;
	}
	
	public boolean equals(Object obj)
	{
		HashSetExample std = (HashSetExample)obj;
		System.out.println("rollNo :- "+rollNo+" std.rollno :- "+std.rollNo);
		return rollNo == std.rollNo;
	}

	public String toString()
	{
		return	rollNo+", "+firstName+" "+lastName; 
	}
	
	public static void main(String[] args) {
		
		System.out.println("Main start...");
		
		HashSet<HashSetExample> hs = new HashSet<HashSetExample>();
		
		hs.add(new HashSetExample(101,"DK","Dusunge"));
		hs.add(new HashSetExample(102,"shan","shaikh"));
		hs.add(new HashSetExample(101,"DK","Dusunge"));
		hs.add(new HashSetExample(111,"MRF","Fadtare"));
		
		
		HashSetExample obj = new HashSetExample(111,"MRF","Fadtare");
		HashSetExample obj1 = new HashSetExample(101,"DK","Dusunge");
		
		System.out.println(obj.equals(obj1));
		
		
		System.out.println(hs);
		
		
		
		System.out.println("Main end");
	}
	
}
