package Thread;

public class DaemonThread extends Thread {
	
	DaemonThread()
	{
		setDaemon(true);
	}
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println("Daemin thread : "+i);
		}
	}
	
	public static void main(String[] args) {
		
		System.out.println("main started...");
		
		Thread main = Thread.currentThread();
		System.out.println(main.getName());
		
		
		UserThread u = new UserThread();
		
		u.start();
		
		DaemonThread d = new DaemonThread();
		u.setName("User Thread MRF");
		d.setName("Daemon thread");
		
		System.out.println("User thread Name :- "+u.getName());
		System.out.println("Daemon thread Name :- "+d.getName());
		d.start();
		
		System.out.println("main ended...");
		
	}

}
