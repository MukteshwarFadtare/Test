package Thread;

public class DaemonTHreadDemo implements Runnable {
	
	public void run()
	{
		System.out.println("my thread....");
	}
	
	
	public static void main(String[] args) {
		
		DaemonTHreadDemo d = new DaemonTHreadDemo();
		Thread t = new Thread(d);
		
		System.out.println(t.isDaemon());
		
		t.setDaemon(true);
		
		System.out.println(t.isDaemon());
		
		t.start();
		//t.setDaemon(true);
	}

}
