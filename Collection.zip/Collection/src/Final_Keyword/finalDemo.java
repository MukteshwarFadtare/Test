package Final_Keyword;




public class finalDemo {
	public static void main(String[] args) {

		final int i =10;
		System.out.println(i);
		final int k =10;
		System.out.println(k);
		
	}

}
