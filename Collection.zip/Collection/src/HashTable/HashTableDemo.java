package HashTable;

import java.util.Hashtable;

public class HashTableDemo {
	public static void main(String[] args) {

		Hashtable ht = new Hashtable();
		ht.put(100, "MRF"); 
		ht.put(101, "MRF");
		ht.put("d", "MRF");
		ht.put(102, "MRF");
		ht.put("s", "MRF");
		
		
		System.out.println("d".hashCode());
		System.out.println("s".hashCode());
		
	
		System.out.println(ht);
	}

}
